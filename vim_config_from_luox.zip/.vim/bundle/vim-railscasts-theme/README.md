# Description

A GUI only color scheme based on the RailsCasts TextMate theme.

# Installation

* Copy railscasts.vim into ~/.vim/colors/ (Unix) or vimfiles/colors/ (Windows) as with 
  other color schemes.

* Type "colorscheme railscasts" into your vimrc file.

# Screenshot

<img src="https://github.com/jpo/vim-railscasts-theme/raw/master/screenshot.png" />
